package com.interview.breeds.serice;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.interview.breeds.model.Response;

@Service
public class BreedsService {
	Map<String, List<String>> data;

	@PostConstruct
	public void init() throws JsonParseException, JsonMappingException, IOException {
		File file = new File("api.json");
		ObjectMapper mapper = new ObjectMapper();
		TypeReference<HashMap<String, List<String>>> typeRef = new TypeReference<HashMap<String, List<String>>>() {
		};

		HashMap<String, List<String>> response = mapper.readValue(file, typeRef);
		data =  response.entrySet().stream().sorted((e1,e2)->e1.getKey().compareTo(e2.getKey())).collect(Collectors.toMap(Entry::getKey, Entry::getValue, (x,y)->y, LinkedHashMap::new ));

	}
	
	public Response fetchBreeds() {
		Response response = new Response();
		response.setMessage(data);
		response.setStatus("success");
		return response;
	}
}
