package com.interview.breeds;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BreedsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BreedsApplication.class, args);
	}

}
