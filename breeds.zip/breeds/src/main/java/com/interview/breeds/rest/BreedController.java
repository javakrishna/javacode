package com.interview.breeds.rest;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.interview.breeds.model.Response;
import com.interview.breeds.serice.BreedsService;

@RestController
@RequestMapping("/breeds")
public class BreedController {


	@Autowired
	private BreedsService breedService;

	@GetMapping
	public Response fetchBreeds() {
		return breedService.fetchBreeds();
	}
}
