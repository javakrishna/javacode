package com.interview.breeds.model;

import java.util.List;
import java.util.Map;

import lombok.Data;


public class Response {
	private Map<String, List<String>> message;

	private String status;

	public Map<String, List<String>> getMessage() {
		return message;
	}

	public void setMessage(Map<String, List<String>> message) {
		this.message = message;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	

}
