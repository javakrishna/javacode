package com.interview.breeds.serice;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.web.client.RestTemplate;

import com.interview.breeds.model.Response;

@SpringBootTest
class BreedsServiceTest {

	@Autowired
	BreedsService breedsService;

	
	@Test
	void testBreeds() {

		Response response = breedsService.fetchBreeds();
		assertEquals("success", response.getStatus());
		assertNotNull(response.getMessage());
		assertEquals("lapphund", response.getMessage().get("finnish").get(0));

		assertEquals("affenpinscher", response.getMessage().entrySet().stream().findFirst().get().getKey());
		assertEquals(3, response.getMessage().get("setter").size());

	}
	//TODO: retrieve the data from api and compare the json strnigs

	@Test
	@Disabled
	public void testAPiResponse() {
		RestTemplate restTemplate = new RestTemplate();
		String apiResponse = restTemplate.getForEntity("https://dog.ceo/api/breeds/list/all", String.class).getBody();
		String localResponse =new TestRestTemplate().getForEntity("http://localhost:8090/breeds", String.class).getBody();
		assertEquals(apiResponse, localResponse);
	}

}
